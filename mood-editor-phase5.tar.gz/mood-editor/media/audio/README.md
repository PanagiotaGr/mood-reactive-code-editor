# media/audio/ — Mood Audio Tracks

Place your ambient audio loops here. The extension looks for these files by default:

| File          | State      | Suggested style                        |
|---------------|------------|----------------------------------------|
| `calm.mp3`    | Calm       | Gentle lo-fi, nature sounds, soft jazz |
| `focused.mp3` | Focused    | Binaural beats, moderate tempo lo-fi   |
| `stressed.mp3`| Stressed   | White noise, slow rain, minimal tones  |

## Requirements

- **Format**: MP3 (best compatibility across Webview engines)
- **Duration**: 30 s – 5 min recommended (they loop automatically)
- **Size**: Keep under 10 MB per file for instant loading
- **Looping**: The player sets `<audio loop>` — seamless loops work best
  (audacity: fade in/out the same few milliseconds at start/end)

## Where to find free loops

- **Freesound.org** — search "lofi loop", "binaural focus", "rain ambience"
  (filter by CC0 licence)
- **Pixabay** — ambient music, royalty-free
- **Zapsplat** — free with account, great lo-fi category

## Customising tracks

You can point the extension at different filenames via Settings:

```json
"moodEditor.audio.tracks.calm":     "my-calm-loop.mp3",
"moodEditor.audio.tracks.focused":  "deep-focus.mp3",
"moodEditor.audio.tracks.stressed": "rain-noise.mp3"
```

## Troubleshooting

If a file is missing the extension will show **one** warning toast and
automatically disable audio for that session. Fix: add the file, then
reload the Extension Development Host window (Developer: Reload Window).

## Privacy

Audio files never leave your machine. They are loaded directly from your
local filesystem via a `vscode-resource://` URI into the hidden Webview.
No CDN, no network request.
