// src/audioPlayer.ts
// ─────────────────────────────────────────────────────────────────────────────
// AudioPlayer — Webview-backed mood audio with smooth fade transitions.
//
// Why Webview?
//   VS Code extensions run in Node.js which has no audio APIs.  The only
//   reliable cross-platform approach is to open a hidden Webview panel that
//   hosts an HTML5 <audio> element.  The Webview is retained (not disposed)
//   so the audio loop continues while monitoring is active.
//
// Architecture:
//   Extension (Node) ──postMessage──► Webview (HTML5)
//     { cmd: "play",  track: "vscode-resource://.../calm.mp3", volume: 0.3 }
//     { cmd: "fade",  targetVolume: 0.3, durationMs: 1000 }
//     { cmd: "stop" }
//     { cmd: "setVolume", volume: 0.3 }
//
// Missing-file handling:
//   If the audio file URI returns a 404 the Webview fires an "error" message
//   back.  The player shows ONE warning toast per missing file and disables
//   audio for that session to avoid spam.

import * as vscode from "vscode";
import * as path from "path";
import { MoodState } from "./types";

// ── Config helpers ────────────────────────────────────────────────────────────

function cfg<T>(key: string, fallback: T): T {
  return vscode.workspace.getConfiguration("moodEditor").get<T>(key, fallback);
}

function audioEnabled(): boolean  { return cfg<boolean>("audio.enabled", false); }
function audioVolume(): number    { return Math.max(0, Math.min(1, cfg<number>("audio.volume", 0.3))); }
function trackFile(state: MoodState): string {
  const defaults: Record<MoodState, string> = {
    [MoodState.Calm]:     "calm.mp3",
    [MoodState.Focused]:  "focused.mp3",
    [MoodState.Stressed]: "stressed.mp3",
  };
  return cfg<string>(`audio.tracks.${state}`, defaults[state]);
}

// ── AudioPlayer ───────────────────────────────────────────────────────────────

export class AudioPlayer implements vscode.Disposable {
  private _panel: vscode.WebviewPanel | null = null;
  private _currentState: MoodState | null = null;
  private _warnedFiles = new Set<string>();   // files we already warned about
  private _audioDisabled = false;             // auto-disabled on persistent error
  private readonly _ctx: vscode.ExtensionContext;

  constructor(ctx: vscode.ExtensionContext) {
    this._ctx = ctx;
  }

  // ── Public API ────────────────────────────────────────────────────────────

  /** React to a mood state change — cross-fades to the matching track. */
  onMoodChange(state: MoodState): void {
    if (!audioEnabled() || this._audioDisabled) { return; }
    if (state === this._currentState) { return; }
    this._currentState = state;
    this._ensurePanel();
    this._fadeToTrack(state);
  }

  /** Stop playback and release the Webview. */
  stop(): void {
    this._currentState = null;
    if (this._panel) {
      this._postMessage({ cmd: "stop" });
      // Keep panel alive — recreating it causes a flash.  Just silence it.
    }
  }

  /** Force-play a specific state (used by manual override commands). */
  forceState(state: MoodState): void {
    this._currentState = state;
    if (!audioEnabled() || this._audioDisabled) { return; }
    this._ensurePanel();
    this._fadeToTrack(state);
  }

  dispose(): void {
    this.stop();
    this._panel?.dispose();
    this._panel = null;
  }

  // ── Private: Webview lifecycle ────────────────────────────────────────────

  private _ensurePanel(): void {
    if (this._panel) { return; }

    this._panel = vscode.window.createWebviewPanel(
      "moodAudio",
      "Mood Audio",          // title (not visible — panel is hidden)
      { viewColumn: vscode.ViewColumn.Beside, preserveFocus: true },
      {
        enableScripts: true,
        retainContextWhenHidden: true,   // keeps audio alive when panel is hidden
        localResourceRoots: [
          vscode.Uri.file(path.join(this._ctx.extensionPath, "media", "audio")),
        ],
      }
    );

    // Panel is purely functional — keep it out of the user's way
    this._panel.iconPath = undefined;

    this._panel.webview.html = this._buildHtml();

    // Listen for messages from the Webview
    this._panel.webview.onDidReceiveMessage((msg: WebviewMsg) => {
      this._handleWebviewMessage(msg);
    });

    // If the user closes the panel, null our reference so it rebuilds next time
    this._panel.onDidDispose(() => {
      this._panel = null;
    });
  }

  private _fadeToTrack(state: MoodState): void {
    const filename = trackFile(state);
    const fileUri  = this._resourceUri(filename);
    const volume   = audioVolume();

    this._postMessage({
      cmd: "play",
      track: fileUri.toString(),
      filename,
      volume,
      fadeDurationMs: 1000,
    });
  }

  private _resourceUri(filename: string): vscode.Uri {
    const diskPath = vscode.Uri.file(
      path.join(this._ctx.extensionPath, "media", "audio", filename)
    );
    return this._panel!.webview.asWebviewUri(diskPath);
  }

  private _postMessage(msg: object): void {
    this._panel?.webview.postMessage(msg);
  }

  private _handleWebviewMessage(msg: WebviewMsg): void {
    if (msg.type === "error") {
      const file: string = msg.filename ?? "unknown";
      if (!this._warnedFiles.has(file)) {
        this._warnedFiles.add(file);
        const missingCount = this._warnedFiles.size;

        vscode.window.showWarningMessage(
          `Mood Editor Audio: "${file}" not found in media/audio/. ` +
          `Add calm.mp3 / focused.mp3 / stressed.mp3 to the media/audio/ folder, ` +
          `or update moodEditor.audio.tracks settings. Audio disabled for this session.`,
          "Open Settings",
          "Dismiss"
        ).then((choice) => {
          if (choice === "Open Settings") {
            vscode.commands.executeCommand(
              "workbench.action.openSettings",
              "moodEditor.audio"
            );
          }
        });

        // Auto-disable after first missing file to prevent repeated errors
        if (missingCount >= 1) {
          this._audioDisabled = true;
          this._postMessage({ cmd: "stop" });
        }
      }
    } else if (msg.type === "ready") {
      // Webview reloaded — re-send current track if we have one
      if (this._currentState && !this._audioDisabled && audioEnabled()) {
        this._fadeToTrack(this._currentState);
      }
    }
  }

  // ── Private: Webview HTML ─────────────────────────────────────────────────

  private _buildHtml(): string {
    // CSP: only allow local extension resources and inline scripts
    return /* html */ `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta
    http-equiv="Content-Security-Policy"
    content="default-src 'none'; media-src ${this._panel!.webview.cspSource}; script-src 'unsafe-inline';"
  >
  <title>Mood Audio</title>
  <style>
    body {
      background: transparent;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
      font-family: var(--vscode-font-family);
      color: var(--vscode-foreground);
      font-size: 12px;
      opacity: 0.6;
    }
    #status { text-align: center; }
  </style>
</head>
<body>
  <div id="status">🎵 Mood Audio Player<br><span id="track-label">idle</span></div>
  <audio id="player" loop></audio>

  <script>
    const vscode  = acquireVsCodeApi();
    const player  = document.getElementById('player');
    const label   = document.getElementById('track-label');
    let   fadeRaf = null;   // requestAnimationFrame handle for fade

    // Notify extension that Webview is ready (handles hot-reload)
    vscode.postMessage({ type: 'ready' });

    // ── Message handler ───────────────────────────────────────────────────
    window.addEventListener('message', (event) => {
      const msg = event.data;
      switch (msg.cmd) {

        case 'play': {
          const isSameTrack = player.src === msg.track && !player.paused;
          if (isSameTrack) {
            // Already playing this track — just ensure target volume
            fadeTo(msg.volume, msg.fadeDurationMs ?? 1000);
            break;
          }
          // Fade out current, swap, fade in
          fadeOut(player.volume, msg.fadeDurationMs ?? 1000, () => {
            player.src    = msg.track;
            player.volume = 0;
            player.load();
            player.play().then(() => {
              fadeTo(msg.volume ?? 0.3, msg.fadeDurationMs ?? 1000);
              label.textContent = msg.filename ?? msg.track.split('/').pop();
            }).catch((err) => {
              // Likely a missing file — inform the extension
              vscode.postMessage({ type: 'error', filename: msg.filename, detail: err.message });
            });
          });
          break;
        }

        case 'stop':
          fadeOut(player.volume, 800, () => {
            player.pause();
            player.src    = '';
            label.textContent = 'idle';
          });
          break;

        case 'setVolume':
          fadeTo(msg.volume, 500);
          break;

        case 'fade':
          fadeTo(msg.targetVolume, msg.durationMs ?? 1000);
          break;
      }
    });

    // ── Audio error handler ───────────────────────────────────────────────
    player.addEventListener('error', () => {
      const filename = player.src.split('/').pop() ?? 'unknown';
      vscode.postMessage({ type: 'error', filename });
      label.textContent = 'file not found: ' + filename;
    });

    // ── Fade helpers (rAF-based, no dependencies) ─────────────────────────
    function fadeTo(targetVol, durationMs, onComplete) {
      if (fadeRaf !== null) { cancelAnimationFrame(fadeRaf); fadeRaf = null; }
      const startVol  = player.volume;
      const startTime = performance.now();
      const delta     = targetVol - startVol;

      if (Math.abs(delta) < 0.001) {
        player.volume = targetVol;
        onComplete?.();
        return;
      }

      function step(now) {
        const elapsed  = now - startTime;
        const progress = Math.min(elapsed / durationMs, 1);
        // ease-in-out quad
        const ease = progress < 0.5
          ? 2 * progress * progress
          : 1 - Math.pow(-2 * progress + 2, 2) / 2;
        player.volume = Math.max(0, Math.min(1, startVol + delta * ease));
        if (progress < 1) {
          fadeRaf = requestAnimationFrame(step);
        } else {
          fadeRaf = null;
          onComplete?.();
        }
      }
      fadeRaf = requestAnimationFrame(step);
    }

    function fadeOut(fromVol, durationMs, onComplete) {
      fadeTo(0, durationMs, onComplete);
    }
  </script>
</body>
</html>`;
  }
}

// ── Internal message types ────────────────────────────────────────────────────

interface WebviewMsg {
  type: string;
  filename?: string;
  detail?: string;
}
