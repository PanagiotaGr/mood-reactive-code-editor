// src/suggestionProvider.ts
// ─────────────────────────────────────────────────────────────────────────────
// SuggestionProvider — surfaces actionable coding tips based on mood state.
//
// Design:
//   • Tips are pulled from a curated per-state bank.
//   • Rate-limited by moodEditor.suggestions.minIntervalMs (default 30 s)
//     so the user is never nagged on every poll tick.
//   • Delivery channel 1: status bar tooltip (always, when suggestions enabled)
//   • Delivery channel 2: toast notification (opt-in, default OFF)
//   • "Show Tip Now" command bypasses the rate limit.
//   • Stops cleanly when monitoring is toggled OFF.

import * as vscode from "vscode";
import { MoodState } from "./types";

// ── Tip banks ─────────────────────────────────────────────────────────────────

const TIPS: Record<MoodState, string[]> = {
  [MoodState.Stressed]: [
    "Break this task into 3 micro-steps — pick the smallest one.",
    "Reduce scope: ship a minimal version first, iterate later.",
    "Run your tests now — green bar resets mental state fast.",
    "Add a TODO comment and move on — don't let one blocker stall you.",
    "Step away for 2 minutes — physical reset improves problem-solving.",
    "Narrow the problem: comment out everything except the failing case.",
    "Ask: what's the single next action? Only that action matters right now.",
  ],
  [MoodState.Focused]: [
    "Keep momentum — resist the urge to context-switch.",
    "Good time for a small, clean refactor — you're in the zone.",
    "Write a focused helper function before the complexity grows.",
    "Add types to this module — you're sharp enough to do it now.",
    "Extract a pure utility — it'll pay dividends this session.",
    "Write the happy-path test while the intent is fresh in your mind.",
  ],
  [MoodState.Calm]: [
    "Perfect time for a bigger refactor — your mind is clear.",
    "Extract a module or service boundary you've been deferring.",
    "Try an advanced snippet or editor shortcut you've been meaning to learn.",
    "Write architectural docs or ADR while things feel simple.",
    "Review open TODOs — calm state is ideal for tackling deferred work.",
    "Explore a new pattern or library — low stakes, high curiosity.",
    "Improve error handling or edge cases — calm focus makes this thorough.",
  ],
};

// ── Config helpers ────────────────────────────────────────────────────────────

function suggestionsEnabled(): boolean {
  return vscode.workspace
    .getConfiguration("moodEditor.suggestions")
    .get<boolean>("enabled", true);
}

function toastEnabled(): boolean {
  return vscode.workspace
    .getConfiguration("moodEditor.suggestions")
    .get<boolean>("toastEnabled", false);
}

function minIntervalMs(): number {
  return vscode.workspace
    .getConfiguration("moodEditor.suggestions")
    .get<number>("minIntervalMs", 30_000);
}

// ── SuggestionProvider ────────────────────────────────────────────────────────

export class SuggestionProvider implements vscode.Disposable {
  private _lastTipMs    = 0;          // timestamp of last tip shown
  private _lastState: MoodState | null = null;
  private _currentTip   = "";         // tip shown in status bar tooltip
  private _tipIndices: Record<MoodState, number> = {
    [MoodState.Stressed]: 0,
    [MoodState.Focused]:  0,
    [MoodState.Calm]:     0,
  };

  private readonly _statusBar: { tooltip: string | vscode.MarkdownString | undefined };
  private readonly _disposables: vscode.Disposable[] = [];

  /**
   * @param statusBarItem  The status bar item whose tooltip we'll update.
   *                       We accept the item directly so we don't need to
   *                       reach into StatusBarController internals.
   */
  constructor(statusBarItem: vscode.StatusBarItem) {
    this._statusBar = statusBarItem;
  }

  // ── Public API ────────────────────────────────────────────────────────────

  /**
   * Called by the engine on each stable state.
   * Enforces the rate-limit; call freely from the poll loop.
   */
  onMoodTick(state: MoodState): void {
    if (!suggestionsEnabled()) { return; }
    const now     = Date.now();
    const elapsed = now - this._lastTipMs;

    // Always update tooltip on state change even within the rate limit
    if (state !== this._lastState) {
      this._lastState = state;
      this._updateTooltip(state, /* forceNew */ false);
    }

    if (elapsed < minIntervalMs()) { return; }
    this._showTip(state, /* isForced */ false);
  }

  /** Bypass rate limit — triggered by "Show Tip Now" command. */
  showTipNow(state: MoodState): void {
    this._showTip(state, /* isForced */ true);
  }

  /** Pause — called when monitoring stops. Clears the tooltip. */
  pause(): void {
    this._statusBar.tooltip = "Mood-Reactive Editor — click for dashboard";
    this._currentTip = "";
  }

  dispose(): void {
    this._disposables.forEach((d) => d.dispose());
  }

  // ── Private ───────────────────────────────────────────────────────────────

  private _showTip(state: MoodState, isForced: boolean): void {
    this._lastTipMs = Date.now();
    this._updateTooltip(state, /* forceNew */ true);

    if (toastEnabled() || isForced) {
      const md = new vscode.MarkdownString(
        `**Mood Editor — ${this._stateName(state)} tip**\n\n${this._currentTip}`
      );
      md.isTrusted = true;

      vscode.window.showInformationMessage(
        `💡 ${this._stateName(state)}: ${this._currentTip}`,
        "Got it"
      );
    }
  }

  private _updateTooltip(state: MoodState, forceNew: boolean): void {
    if (forceNew || !this._currentTip) {
      this._currentTip = this._nextTip(state);
    }
    const emoji = state === MoodState.Stressed ? "🔥"
                : state === MoodState.Focused  ? "⚡"
                : "😌";
    this._statusBar.tooltip = [
      `${emoji} Mood-Reactive Editor — ${this._stateName(state)}`,
      ``,
      `💡 Tip: ${this._currentTip}`,
      ``,
      `Click to open dashboard`,
    ].join("\n");
  }

  /** Round-robin through the tip bank for this state. */
  private _nextTip(state: MoodState): string {
    const bank = TIPS[state];
    const idx  = this._tipIndices[state] % bank.length;
    this._tipIndices[state] = idx + 1;
    return bank[idx];
  }

  private _stateName(state: MoodState): string {
    return state === MoodState.Calm ? "Calm/Productive" : state.charAt(0).toUpperCase() + state.slice(1);
  }
}
