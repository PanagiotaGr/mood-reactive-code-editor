// src/extension.ts
// ─────────────────────────────────────────────────────────────────────────────
// Extension entry point — Phase 5 final.
//
// New in Phase 5:
//   • AudioPlayer     — Webview-backed HTML5 audio, fades on state change
//   • SuggestionProvider — rate-limited tips; updates status bar tooltip
//   • "Mood Editor: Show Tip Now" command
//   • stop() tears down audio + pauses suggestions

import * as vscode from "vscode";
import { MoodState, MoodReading } from "./types";
import { ThemeManager } from "./themeManager";
import { StatusBarController } from "./statusBar";
import { ServiceClient } from "./serviceClient";
import { MoodEngine } from "./moodEngine";
import { AudioPlayer } from "./audioPlayer";
import { SuggestionProvider } from "./suggestionProvider";

// ── Module-level singletons ───────────────────────────────────────────────────

let themeManager:      ThemeManager;
let statusBar:         StatusBarController;
let serviceClient:     ServiceClient;
let moodEngine:        MoodEngine;
let audioPlayer:       AudioPlayer;
let suggestionProvider: SuggestionProvider;

// ── Helpers ───────────────────────────────────────────────────────────────────

const MANUAL_SCORES: Record<MoodState, number> = {
  [MoodState.Calm]:     0.1,
  [MoodState.Focused]:  0.45,
  [MoodState.Stressed]: 0.8,
};

function manualReading(state: MoodState): MoodReading {
  return { stress_score: MANUAL_SCORES[state], state, timestamp: Date.now(), source: "manual" };
}

async function applyMoodManual(reading: MoodReading): Promise<void> {
  await themeManager.applyState(reading.state);
  statusBar.update(reading);
  audioPlayer.forceState(reading.state);
  suggestionProvider.showTipNow(reading.state);
}

function engineSummary(): string {
  const s = moodEngine.engineState;
  if (s.status === "idle")    { return "Monitoring OFF — Toggle Monitoring to start"; }
  if (s.status === "offline") { return `⚠ Service offline (${s.consecutiveErrors} errors) — state: ${s.currentMoodState}`; }
  const pct    = Math.round(s.smoothedScore * 100);
  const rawPct = Math.round(s.lastRawScore  * 100);
  return `● ${s.currentMoodState}  smoothed=${pct}%  raw=${rawPct}%`;
}

// ── Activation ────────────────────────────────────────────────────────────────

export async function activate(ctx: vscode.ExtensionContext): Promise<void> {

  themeManager       = new ThemeManager();
  statusBar          = new StatusBarController();
  serviceClient      = new ServiceClient();
  moodEngine         = new MoodEngine(serviceClient, themeManager, statusBar);
  audioPlayer        = new AudioPlayer(ctx);
  suggestionProvider = new SuggestionProvider(statusBar.item);

  // ── Wire engine events ──────────────────────────────────────────────────

  // onStateChange: audio cross-fade (only on transitions)
  ctx.subscriptions.push(
    moodEngine.onStateChange((reading) => {
      audioPlayer.onMoodChange(reading.state);
    })
  );

  // onTick: suggestion rate-limiter (every 2 s poll, internally gated to 30 s)
  ctx.subscriptions.push(
    moodEngine.onTick((reading) => {
      suggestionProvider.onMoodTick(reading.state);
    })
  );

  // ── Commands ────────────────────────────────────────────────────────────

  ctx.subscriptions.push(

    // ── Manual state overrides ────────────────────────────────────────────
    vscode.commands.registerCommand("moodEditor.setCalm", async () => {
      await applyMoodManual(manualReading(MoodState.Calm));
      vscode.window.showInformationMessage("Mood Editor → Calm 😌");
    }),

    vscode.commands.registerCommand("moodEditor.setFocused", async () => {
      await applyMoodManual(manualReading(MoodState.Focused));
      vscode.window.showInformationMessage("Mood Editor → Focused ⚡");
    }),

    vscode.commands.registerCommand("moodEditor.setStressed", async () => {
      await applyMoodManual(manualReading(MoodState.Stressed));
      vscode.window.showInformationMessage("Mood Editor → Stressed 🔥");
    }),

    // ── Monitoring toggle ─────────────────────────────────────────────────
    vscode.commands.registerCommand(
      "moodEditor.toggleMonitoring",
      async () => {
        const isRunning = moodEngine.status === "running";
        if (isRunning) {
          moodEngine.stop();
          audioPlayer.stop();
          suggestionProvider.pause();
          vscode.window.showInformationMessage("Mood Editor: Monitoring OFF ⏹");
        } else {
          await moodEngine.start();
          const pollMs = vscode.workspace
            .getConfiguration("moodEditor")
            .get<number>("pollIntervalMs", 2000);
          vscode.window.showInformationMessage(
            `Mood Editor: Monitoring ON ▶  polling every ${pollMs} ms`
          );
        }
      }
    ),

    // ── Show Tip Now ──────────────────────────────────────────────────────
    vscode.commands.registerCommand("moodEditor.showTipNow", () => {
      const state = moodEngine.engineState.currentMoodState;
      suggestionProvider.showTipNow(state);
    }),

    // ── Dashboard (quick-pick) ────────────────────────────────────────────
    vscode.commands.registerCommand("moodEditor.showDashboard", () => {
      type DashItem = vscode.QuickPickItem & { id: string };
      const isRunning   = moodEngine.status === "running";
      const toggleLabel = isRunning
        ? "$(debug-stop)  Stop Monitoring"
        : "$(play)  Start Monitoring";

      const audioOn = vscode.workspace
        .getConfiguration("moodEditor")
        .get<boolean>("audio.enabled", false);

      const items: DashItem[] = [
        { label: "$(smiley)  Set Calm",        id: "moodEditor.setCalm"          },
        { label: "$(zap)  Set Focused",        id: "moodEditor.setFocused"       },
        { label: "$(flame)  Set Stressed",     id: "moodEditor.setStressed"      },
        { label: toggleLabel,                  id: "moodEditor.toggleMonitoring" },
        { label: "$(lightbulb)  Show Tip Now", id: "moodEditor.showTipNow"       },
        {
          label: audioOn ? "$(unmute)  Audio ON" : "$(mute)  Audio OFF",
          description: "Toggle in Settings → moodEditor.audio.enabled",
          id: "workbench.action.openSettings",
        },
      ];

      vscode.window.showQuickPick(items, {
        placeHolder: engineSummary(),
        title: "Mood-Reactive Editor",
      }).then((picked) => {
        if (picked) {
          if (picked.id === "workbench.action.openSettings") {
            vscode.commands.executeCommand(picked.id, "moodEditor.audio");
          } else {
            vscode.commands.executeCommand(picked.id);
          }
        }
      });
    }),

    // ── Cleanup ───────────────────────────────────────────────────────────
    moodEngine,
    statusBar,
    audioPlayer,
    suggestionProvider,
  );

  vscode.window.showInformationMessage(
    "Mood-Reactive Editor activated 🧠 — Toggle Monitoring to start. " +
    "Enable audio in Settings (moodEditor.audio.enabled)."
  );
}

export function deactivate(): void {
  // All disposables called automatically via ctx.subscriptions
}
