// src/serviceClient.ts
// ─────────────────────────────────────────────────────────────────────────────
// Thin HTTP client for the local Python inference service.
//
// Phase 4 schema update
//   stress_score is now CANONICAL 0-100 (int) from the Python service.
//   The normaliser auto-detects 0-1 floats (Phase 2 stub compat) vs 0-100 ints.
//   Python `state` vocabulary -> MoodState mapping:
//     productive -> MoodState.Calm
//     neutral    -> MoodState.Focused
//     stressed   -> MoodState.Stressed
//
// Network errors are caught and returned as null so callers can
// handle "offline" without crashing or spamming notifications.

import * as vscode from "vscode";
import { MoodState, MoodReading } from "./types";

// ── Python response shape (Phase 4 canonical + Phase 2 compat) ───────────────

interface RawInferResponse {
  stress_score?: number;   // CANONICAL: int 0-100 (Phase 4) or float 0-1 (Phase 2 stub)
  stress_pct?: number;     // legacy alias from Phase 2; still accepted
  state?: string;          // "productive" | "neutral" | "stressed"
  timestamp_ms?: number;
  source?: string;         // "webcam" | "stub" | "fallback"
  warning?: string;        // present when source != "webcam"
  signals?: Record<string, number>;  // debug fields (ear, brow, mouth, ...)
}

interface RawHealthResponse {
  ok?: boolean;
  uptime_s?: number;
}

// ── State vocabulary map ──────────────────────────────────────────────────────

const PYTHON_STATE_MAP: Record<string, MoodState> = {
  productive: MoodState.Calm,
  neutral:    MoodState.Focused,
  stressed:   MoodState.Stressed,
  // Pass-through in case future phases emit these directly
  calm:       MoodState.Calm,
  focused:    MoodState.Focused,
};

// ── Client ────────────────────────────────────────────────────────────────────

export class ServiceClient {
  private get baseUrl(): string {
    return vscode.workspace
      .getConfiguration("moodEditor")
      .get<string>("pythonServiceUrl", "http://localhost:8765");
  }

  /**
   * Attempt GET /health.
   * Returns true if the service is reachable and reports ok:true.
   * Returns false on any network or parse error.
   */
  async health(): Promise<boolean> {
    try {
      const res = await this._fetch("/health");
      if (!res.ok) { return false; }
      const body: RawHealthResponse = await res.json();
      return body.ok === true;
    } catch {
      return false;
    }
  }

  /**
   * Attempt GET /infer.
   * Returns a normalised MoodReading on success, or null on any failure.
   * Callers must treat null as "service offline / reading unavailable".
   */
  async infer(): Promise<MoodReading | null> {
    try {
      const res = await this._fetch("/infer");
      if (!res.ok) { return null; }

      const raw: RawInferResponse = await res.json();
      return this._normalise(raw);
    } catch {
      return null;
    }
  }

  // ── Private helpers ──────────────────────────────────────────────────────

  /** Thin fetch wrapper with a short timeout so the poller never hangs. */
  private async _fetch(path: string): Promise<Response> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 1500); // 1.5 s hard timeout
    try {
      return await fetch(`${this.baseUrl}${path}`, {
        signal: controller.signal,
        headers: { Accept: "application/json" },
      });
    } finally {
      clearTimeout(timer);
    }
  }

  /** Convert a raw Python response into a typed MoodReading.
   *
   * Phase 4 canonical: stress_score is 0-100 (int).
   * Phase 2 stub compat: stress_score may be 0.0-1.0 (float) -- auto-detected
   * by checking whether the value is <= 1.0 with a decimal component.
   */
  private _normalise(raw: RawInferResponse): MoodReading {
    // ── Score normalisation ───────────────────────────────────────────────
    let score01: number;  // internal representation always 0-1

    if (typeof raw.stress_score === "number") {
      const v = raw.stress_score;
      // Heuristic: Phase 4 sends integers 0-100; Phase 2 stub sends floats 0-1.
      // If value > 1.0 it must be the 0-100 scale.
      score01 = v > 1.0
        ? Math.max(0, Math.min(100, v)) / 100   // 0-100 -> 0-1
        : Math.max(0, Math.min(1,   v));         // already 0-1
    } else if (typeof raw.stress_pct === "number") {
      score01 = Math.max(0, Math.min(100, raw.stress_pct)) / 100;
    } else {
      score01 = 0.5; // unknown -- default to mid-range (focused)
    }

    // ── State mapping ─────────────────────────────────────────────────────
    const rawState = (raw.state ?? "neutral").toLowerCase().trim();
    const state: MoodState = PYTHON_STATE_MAP[rawState] ?? MoodState.Focused;

    return {
      stress_score: score01,   // MoodReading.stress_score is always 0-1 internally
      state,
      timestamp: raw.timestamp_ms ?? Date.now(),
      source: "service",
    };
  }
}
