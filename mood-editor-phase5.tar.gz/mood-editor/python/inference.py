"""
python/inference.py
──────────────────────────────────────────────────────────────────────────────
Webcam-based stress heuristic engine (Phase 4).

Privacy guarantees
  • Frames are processed in-memory and immediately discarded — never written
    to disk, logged, or sent over any network interface.
  • Only the derived scalar signals (three floats) and the aggregated score
    leave this module.

Stress signals
  ┌─────────────────┬───────────────────────────────────────────────────────┐
  │ Signal          │ Landmark geometry                                      │
  ├─────────────────┼───────────────────────────────────────────────────────┤
  │ EAR (eye        │ Ratio of eye height to width using 6 landmarks per    │
  │ aspect ratio)   │ eye. Low sustained EAR → squinting / fatigue.         │
  │                 │ Very low rapid EAR drops → blink events.              │
  ├─────────────────┼───────────────────────────────────────────────────────┤
  │ Brow furrow     │ Vertical distance from medial brow landmark to upper  │
  │                 │ eyelid, normalised by inter-eye distance.  Decreases  │
  │                 │ when brows pull down / together (concentration/stress).│
  ├─────────────────┼───────────────────────────────────────────────────────┤
  │ Mouth tension   │ Vertical lip gap normalised by face height.  Decreases│
  │                 │ when lips press together (jaw tension / stress).       │
  └─────────────────┴───────────────────────────────────────────────────────┘

All three signals are z-scored against a short per-session baseline, clamped,
and linearly combined into a single stress_score (0–100).

Configuration (environment variables)
  MOOD_CAMERA_INDEX   int   Camera device index (default 0)
  MOOD_WINDOW_SECS    int   Rolling-window length in seconds (default 15)
  MOOD_FPS_TARGET     int   Target capture framerate (default 15)
  MOOD_THRESH_NEUTRAL int   stress_score threshold for "neutral" state (default 35)
  MOOD_THRESH_STRESS  int   stress_score threshold for "stressed" state (default 65)
"""

from __future__ import annotations

import logging
import math
import os
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Literal, Optional

logger = logging.getLogger(__name__)

# ── Lazy imports (only loaded when camera starts) ─────────────────────────────
# This keeps the FastAPI startup fast even if mediapipe/cv2 are installed but
# the user never calls /camera/start.

def _import_cv2():
    import cv2  # type: ignore
    return cv2

def _import_mp():
    import mediapipe as mp  # type: ignore
    return mp


# ── Configuration ─────────────────────────────────────────────────────────────

CAMERA_INDEX   = int(os.getenv("MOOD_CAMERA_INDEX",  "0"))
WINDOW_SECS    = int(os.getenv("MOOD_WINDOW_SECS",   "15"))
FPS_TARGET     = int(os.getenv("MOOD_FPS_TARGET",    "15"))
THRESH_NEUTRAL = int(os.getenv("MOOD_THRESH_NEUTRAL","35"))
THRESH_STRESS  = int(os.getenv("MOOD_THRESH_STRESS", "65"))

# Landmark indices (MediaPipe FaceMesh 468-point model)
# Reference: https://github.com/google/mediapipe/blob/master/mediapipe/modules/face_geometry/data/canonical_face_model_uv_visualization.png

# Right eye (from subject's perspective)
_R_EYE = [33, 160, 158, 133, 153, 144]
# Left eye
_L_EYE = [362, 385, 387, 263, 373, 380]
# Medial brow landmarks (inner corners of eyebrows)
_R_BROW_INNER = 55    # right medial brow
_L_BROW_INNER = 285   # left medial brow
# Upper eyelid reference points
_R_EYE_UPPER  = 159
_L_EYE_UPPER  = 386
# Inter-eye reference (outer eye corners)
_R_EYE_OUTER  = 33
_L_EYE_OUTER  = 263
# Lip landmarks
_LIP_UPPER    = 13    # upper lip centre
_LIP_LOWER    = 14    # lower lip centre
# Chin and forehead for face-height normalisation
_CHIN         = 152
_FOREHEAD     = 10


# ── Signal frame dataclass ────────────────────────────────────────────────────

@dataclass
class SignalFrame:
    """One frame's worth of derived signals."""
    timestamp: float        # time.monotonic()
    ear:   float            # eye aspect ratio (higher = more open)
    brow:  float            # brow–eye distance ratio (lower = more furrowed)
    mouth: float            # lip gap ratio (lower = more compressed)
    face_detected: bool


# ── Rolling window accumulator ────────────────────────────────────────────────

class SignalWindow:
    """
    Maintains a time-bounded deque of SignalFrames.
    Computes per-session baselines and returns the current stress score.
    """

    def __init__(self, window_secs: int = WINDOW_SECS) -> None:
        self._window_secs = window_secs
        self._frames: Deque[SignalFrame] = deque()
        # Running sums for cheap mean computation
        self._sum_ear   = 0.0
        self._sum_brow  = 0.0
        self._sum_mouth = 0.0
        self._n         = 0
        # Baseline (first 5 s of detected frames, per-session)
        self._baseline_ear:   Optional[float] = None
        self._baseline_brow:  Optional[float] = None
        self._baseline_mouth: Optional[float] = None
        self._baseline_frames: list[SignalFrame] = []
        self._baseline_locked = False

    def push(self, frame: SignalFrame) -> None:
        """Add a frame; evict frames older than window_secs."""
        now = frame.timestamp
        self._frames.append(frame)
        if frame.face_detected:
            self._sum_ear   += frame.ear
            self._sum_brow  += frame.brow
            self._sum_mouth += frame.mouth
            self._n         += 1
            self._maybe_collect_baseline(frame)

        # Evict expired frames
        cutoff = now - self._window_secs
        while self._frames and self._frames[0].timestamp < cutoff:
            old = self._frames.popleft()
            if old.face_detected:
                self._sum_ear   -= old.ear
                self._sum_brow  -= old.brow
                self._sum_mouth -= old.mouth
                self._n         -= 1

    def _maybe_collect_baseline(self, frame: SignalFrame) -> None:
        if self._baseline_locked:
            return
        self._baseline_frames.append(frame)
        # Lock baseline after 5 seconds of real data
        age = frame.timestamp - self._baseline_frames[0].timestamp
        if age >= 5.0 and len(self._baseline_frames) >= 10:
            ears   = [f.ear   for f in self._baseline_frames]
            brows  = [f.brow  for f in self._baseline_frames]
            mouths = [f.mouth for f in self._baseline_frames]
            self._baseline_ear   = sum(ears)   / len(ears)
            self._baseline_brow  = sum(brows)  / len(brows)
            self._baseline_mouth = sum(mouths) / len(mouths)
            self._baseline_locked = True
            logger.info(
                "Baseline locked: EAR=%.3f  brow=%.3f  mouth=%.3f",
                self._baseline_ear, self._baseline_brow, self._baseline_mouth,
            )

    @property
    def has_baseline(self) -> bool:
        return self._baseline_locked

    def current_means(self) -> tuple[float, float, float]:
        """Return (mean_ear, mean_brow, mean_mouth) over the active window."""
        if self._n == 0:
            return (0.3, 0.4, 0.05)  # neutral defaults
        return (
            self._sum_ear   / self._n,
            self._sum_brow  / self._n,
            self._sum_mouth / self._n,
        )

    def stress_score(self) -> tuple[int, dict[str, float]]:
        """
        Compute stress_score (0–100) from the rolling window.

        Returns
        -------
        score   int   0 = calm, 100 = maximum stress
        signals dict  raw signal means for debug output
        """
        mean_ear, mean_brow, mean_mouth = self.current_means()

        if self._baseline_locked:
            b_ear   = self._baseline_ear   or mean_ear   or 1e-6
            b_brow  = self._baseline_brow  or mean_brow  or 1e-6
            b_mouth = self._baseline_mouth or mean_mouth or 1e-6
        else:
            # No baseline yet — use sensible physiological midpoints
            b_ear, b_brow, b_mouth = 0.28, 0.42, 0.04

        # ── Per-signal stress component (0–1 each) ────────────────────────
        #
        # EAR:   below baseline → squinting/fatigue → stress↑
        #        component = clamp((b - cur) / b, 0, 1)
        ear_stress = _clamp01((b_ear - mean_ear) / max(b_ear, 1e-6))

        # Brow:  below baseline → furrowing → stress↑
        brow_stress = _clamp01((b_brow - mean_brow) / max(b_brow, 1e-6))

        # Mouth: below baseline → compressed lips → stress↑
        mouth_stress = _clamp01((b_mouth - mean_mouth) / max(b_mouth, 1e-6))

        # ── Weighted combination ──────────────────────────────────────────
        # Brow furrow is the most reliable single-frame stress indicator;
        # EAR is noisier (blinks); mouth tension is a secondary signal.
        combined = (
            0.35 * ear_stress
            + 0.40 * brow_stress
            + 0.25 * mouth_stress
        )

        score = int(round(_clamp01(combined) * 100))

        signals = {
            "ear":         round(mean_ear,   4),
            "brow":        round(mean_brow,  4),
            "mouth":       round(mean_mouth, 4),
            "ear_stress":  round(ear_stress,   3),
            "brow_stress": round(brow_stress,  3),
            "mouth_stress":round(mouth_stress, 3),
            "baseline_locked": float(self._baseline_locked),
            "window_n":    float(self._n),
        }
        return score, signals


def _clamp01(v: float) -> float:
    return max(0.0, min(1.0, v))


# ── Geometry helpers ──────────────────────────────────────────────────────────

def _dist(a, b) -> float:
    """Euclidean distance between two landmark objects."""
    return math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2)


def _ear(lm, indices: list[int]) -> float:
    """
    Eye Aspect Ratio from 6 ordered landmarks:
      [outer, top1, top2, inner, bot1, bot2]
    EAR = (|p2-p6| + |p3-p5|) / (2 * |p1-p4|)
    """
    p = [lm[i] for i in indices]
    vertical   = _dist(p[1], p[5]) + _dist(p[2], p[4])
    horizontal = 2.0 * _dist(p[0], p[3])
    if horizontal < 1e-9:
        return 0.0
    return vertical / horizontal


def _brow_metric(lm) -> float:
    """
    Brow–eye distance: average vertical gap between medial brow and upper
    eyelid, normalised by inter-outer-eye distance.
    Smaller → more furrowed.
    """
    inter_eye = _dist(lm[_R_EYE_OUTER], lm[_L_EYE_OUTER])
    if inter_eye < 1e-9:
        return 0.4  # fallback
    r_gap = abs(lm[_R_BROW_INNER].y - lm[_R_EYE_UPPER].y)
    l_gap = abs(lm[_L_BROW_INNER].y - lm[_L_EYE_UPPER].y)
    return ((r_gap + l_gap) / 2.0) / inter_eye


def _mouth_metric(lm) -> float:
    """
    Lip gap normalised by face height.
    Smaller → more compressed lips.
    """
    face_h = abs(lm[_CHIN].y - lm[_FOREHEAD].y)
    if face_h < 1e-9:
        return 0.04  # fallback
    gap = abs(lm[_LIP_UPPER].y - lm[_LIP_LOWER].y)
    return gap / face_h


def _extract_signals(landmarks) -> tuple[float, float, float]:
    """Return (ear, brow, mouth) from a single FaceMesh landmark list."""
    lm  = landmarks.landmark
    ear = (_ear(lm, _R_EYE) + _ear(lm, _L_EYE)) / 2.0
    brow  = _brow_metric(lm)
    mouth = _mouth_metric(lm)
    return ear, brow, mouth


# ── Camera capture engine ─────────────────────────────────────────────────────

@dataclass
class CameraState:
    running:       bool                   = False
    error:         Optional[str]          = None
    last_frame_ts: Optional[float]        = None
    frames_total:  int                    = 0
    faces_detected:int                    = 0
    window:        SignalWindow           = field(default_factory=SignalWindow)


_cam_state  = CameraState()
_cam_lock   = threading.Lock()
_cam_thread: Optional[threading.Thread] = None


def camera_start() -> dict:
    """
    Launch the background capture thread.
    Returns immediately; use GET /infer to read results.
    Idempotent — safe to call multiple times.
    """
    global _cam_thread

    with _cam_lock:
        if _cam_state.running:
            return {"started": False, "reason": "already_running"}
        _cam_state.running       = True
        _cam_state.error         = None
        _cam_state.frames_total  = 0
        _cam_state.faces_detected= 0
        _cam_state.window        = SignalWindow(WINDOW_SECS)

    _cam_thread = threading.Thread(
        target=_capture_loop,
        name="mood-cam",
        daemon=True,   # thread dies automatically when the process exits
    )
    _cam_thread.start()
    return {"started": True}


def camera_stop() -> dict:
    """Signal the capture loop to stop. Returns once the thread has joined."""
    with _cam_lock:
        if not _cam_state.running:
            return {"stopped": False, "reason": "not_running"}
        _cam_state.running = False

    if _cam_thread and _cam_thread.is_alive():
        _cam_thread.join(timeout=3.0)
    return {"stopped": True}


def camera_running() -> bool:
    return _cam_state.running


def latest_reading() -> dict:
    """
    Return the most recent inference result.

    If the camera has never been started or a face has not been seen yet,
    returns source="fallback" so callers know to treat the result with
    lower confidence.
    """
    with _cam_lock:
        running = _cam_state.running
        error   = _cam_state.error
        window  = _cam_state.window
        last_ts = _cam_state.last_frame_ts

    score, signals = window.stress_score()
    state = _score_to_state(score)

    source: Literal["webcam", "fallback"]
    warning: Optional[str] = None

    if not running:
        source  = "fallback"
        warning = "Camera not started — call POST /camera/start"
    elif error:
        source  = "fallback"
        warning = f"Camera error: {error}"
    elif last_ts is None or (time.monotonic() - last_ts) > 5.0:
        source  = "fallback"
        warning = "No recent webcam frame — face may not be visible"
    else:
        source = "webcam"

    return {
        "stress_score": score,             # canonical 0–100
        "state":        state,
        "source":       source,
        "signals":      signals,
        "timestamp_ms": int(time.time() * 1000),
        **({"warning": warning} if warning else {}),
    }


def _score_to_state(score: int) -> str:
    if score < THRESH_NEUTRAL:
        return "productive"
    if score < THRESH_STRESS:
        return "neutral"
    return "stressed"


# ── Capture loop (runs in daemon thread) ─────────────────────────────────────

def _capture_loop() -> None:
    cv2 = _import_cv2()
    mp  = _import_mp()

    cap = cv2.VideoCapture(CAMERA_INDEX)
    if not cap.isOpened():
        with _cam_lock:
            _cam_state.error   = f"Cannot open camera index {CAMERA_INDEX}"
            _cam_state.running = False
        logger.error("Cannot open camera %d", CAMERA_INDEX)
        return

    # Lower resolution for speed; FaceMesh works fine at 480p
    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, FPS_TARGET)

    face_mesh = mp.solutions.face_mesh.FaceMesh(
        max_num_faces=1,
        refine_landmarks=False,   # faster; we don't need iris landmarks
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    )

    frame_interval = 1.0 / FPS_TARGET
    last_frame_time = 0.0

    try:
        while True:
            with _cam_lock:
                if not _cam_state.running:
                    break

            now = time.monotonic()
            elapsed = now - last_frame_time
            if elapsed < frame_interval:
                time.sleep(frame_interval - elapsed)
                continue

            ret, frame = cap.read()
            if not ret:
                logger.warning("Failed to read frame — skipping")
                continue

            last_frame_time = time.monotonic()

            # ── Inference (no frame stored after this block) ─────────────
            # Convert BGR→RGB in-place (MediaPipe expects RGB)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            del frame   # release immediately

            rgb.flags.writeable = False
            results = face_mesh.process(rgb)
            del rgb     # release immediately

            face_detected = (
                results.multi_face_landmarks is not None
                and len(results.multi_face_landmarks) > 0
            )

            if face_detected:
                landmarks = results.multi_face_landmarks[0]
                ear, brow, mouth = _extract_signals(landmarks)
            else:
                ear = brow = mouth = 0.0

            sig = SignalFrame(
                timestamp=last_frame_time,
                ear=ear,
                brow=brow,
                mouth=mouth,
                face_detected=face_detected,
            )

            with _cam_lock:
                _cam_state.window.push(sig)
                _cam_state.last_frame_ts = last_frame_time
                _cam_state.frames_total += 1
                if face_detected:
                    _cam_state.faces_detected += 1

    except Exception as exc:
        logger.exception("Capture loop crashed: %s", exc)
        with _cam_lock:
            _cam_state.error   = str(exc)
            _cam_state.running = False
    finally:
        face_mesh.close()
        cap.release()
        logger.info(
            "Camera released. Total frames: %d, faces detected: %d",
            _cam_state.frames_total,
            _cam_state.faces_detected,
        )
