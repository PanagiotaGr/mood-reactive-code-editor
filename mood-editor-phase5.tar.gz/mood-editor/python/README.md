# Mood-Reactive Editor — Python Inference Service

Local-only FastAPI micro-service.
**No webcam frames, scores, or personal data ever leave your machine.**

---

## Requirements

| Tool    | Version          |
|---------|------------------|
| Python  | 3.9 – 3.11 (recommended); 3.12 needs mediapipe==0.10.9 |
| pip     | 23+              |
| Webcam  | optional (service falls back to stub if absent)         |

---

## Setup

```bash
cd mood-reactive-editor/python

# 1. Create an isolated environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
```

### Apple Silicon (M1 / M2 / M3)

```bash
# Replace opencv-python-headless with the full build
pip install opencv-python==4.9.0.80 mediapipe==0.10.14 fastapi uvicorn pydantic numpy
```

### Python 3.12

```bash
# mediapipe 0.10.9 is the last release with 3.12 wheels
pip install mediapipe==0.10.9 opencv-python-headless fastapi uvicorn pydantic numpy
```

---

## Running the service

```bash
# Development (auto-reload on file save)
uvicorn main:app --host 127.0.0.1 --port 8765 --reload

# Background (production)
uvicorn main:app --host 127.0.0.1 --port 8765
```

The service binds to **localhost only** — unreachable from other machines.

---

## Endpoints

| Method | Path             | Description |
|--------|------------------|-------------|
| GET    | `/health`        | Liveness probe — `{ ok, uptime_s, camera_running }` |
| GET    | `/infer`         | Latest stress reading (webcam or stub fallback) |
| GET    | `/infer?seed=42` | Seeded stub reading (CI-friendly, camera-independent) |
| GET    | `/infer/batch`   | n stub readings in one call |
| POST   | `/camera/start`  | Start webcam capture in background thread |
| POST   | `/camera/stop`   | Stop webcam capture + release device |
| GET    | `/camera/status` | Camera diagnostics (frames, baseline, errors) |
| GET    | `/docs`          | Swagger UI |

---

## Response schema (canonical, Phase 4+)

```json
{
  "stress_score": 42,
  "state": "neutral",
  "source": "webcam",
  "signals": {
    "ear": 0.291,
    "brow": 0.381,
    "mouth": 0.038,
    "ear_stress": 0.12,
    "brow_stress": 0.44,
    "mouth_stress": 0.08,
    "baseline_locked": 1.0,
    "window_n": 215.0
  },
  "timestamp_ms": 1712000000000
}
```

### Field reference

| Field          | Type    | Description |
|----------------|---------|-------------|
| `stress_score` | int 0-100 | **Canonical**. 0 = fully calm, 100 = maximum stress |
| `state`        | string  | `productive` / `neutral` / `stressed` |
| `source`       | string  | `webcam` / `stub` / `fallback` |
| `signals`      | object  | Debug signal values; **only present when `source=webcam`** |
| `warning`      | string  | Explanation when source is not webcam; omitted otherwise |
| `cycle_index`  | int     | Stub cycle step 0-7; omitted in webcam mode |

### State thresholds (configurable via env vars)

| State        | stress_score range | Env var              |
|--------------|--------------------|----------------------|
| `productive` | 0 – 34             | `MOOD_THRESH_NEUTRAL=35` |
| `neutral`    | 35 – 64            | `MOOD_THRESH_STRESS=65`  |
| `stressed`   | 65 – 100           |                          |

---

## Using the webcam

```bash
# Start the service, then in another terminal:
curl -X POST http://localhost:8765/camera/start
# -> {"ok": true, "detail": "Camera capture started"}

curl http://localhost:8765/infer
# -> source="fallback" for first ~5 s (baseline capture)
# -> source="webcam" once baseline is locked

curl http://localhost:8765/camera/status
# -> {"running": true, "frames_total": 87, "baseline_locked": true, ...}

curl -X POST http://localhost:8765/camera/stop
```

### Environment variables

| Variable             | Default | Description |
|----------------------|---------|-------------|
| `MOOD_CAMERA_INDEX`  | `0`     | Camera device index (try 1 if 0 is wrong device) |
| `MOOD_WINDOW_SECS`   | `15`    | Rolling window duration in seconds |
| `MOOD_FPS_TARGET`    | `15`    | Target capture framerate |
| `MOOD_THRESH_NEUTRAL`| `35`    | stress_score threshold: productive -> neutral |
| `MOOD_THRESH_STRESS` | `65`    | stress_score threshold: neutral -> stressed |

```bash
MOOD_CAMERA_INDEX=1 MOOD_WINDOW_SECS=10 uvicorn main:app --port 8765
```

---

## Privacy design

- **Frames are never written to disk.** Each frame is decoded in RAM,
  processed by MediaPipe FaceMesh, and immediately released.
- **Only three scalars leave the inference module:** `ear`, `brow`, `mouth`
  (floating-point ratios, not images or biometric templates).
- **The service binds to 127.0.0.1 only.** No listener on any external interface.
- **No external HTTP calls** are made by the service at any time.

---

## Heuristic signals

| Signal | Landmarks used | What it measures |
|--------|----------------|-----------------|
| **EAR** (eye aspect ratio) | 6 pts per eye | Eye openness; low sustained EAR = fatigue/squinting |
| **Brow furrow** | Medial brow + upper eyelid | Brow-to-eye gap; lower = furrowing (concentration/stress) |
| **Mouth tension** | Upper/lower lip centre, chin, forehead | Lip compression; lower = jaw tension |

Weighted combination: `0.35×EAR_stress + 0.40×brow_stress + 0.25×mouth_stress`

All signals are normalised against a **per-session 5-second baseline** captured
at startup, so individual differences in face geometry do not affect accuracy.

---

## Troubleshooting

### `Cannot open camera index 0`
- Try `MOOD_CAMERA_INDEX=1` (external webcam may be at index 1)
- On Linux: check `ls /dev/video*` — device may need `chmod a+rw`
- On macOS: grant Terminal / VS Code camera permission in System Settings → Privacy

### `mediapipe` install fails
- Python 3.12: use `mediapipe==0.10.9`
- Apple Silicon: install Rosetta or use `mediapipe==0.10.14` with conda

### `source` stays `"fallback"` even with camera running
- Look at `/camera/status` — check `baseline_locked` (needs ~5 s of face visibility)
- Ensure your face is well-lit and centred in frame
- Check `faces_detected` — if 0 after 10 s, detection may be failing

### High CPU usage
- Lower `MOOD_FPS_TARGET` to `10` or `8`
- Use `opencv-python-headless` (excludes GUI backends)
- FaceMesh with `refine_landmarks=False` is already the fast path

### Service port already in use
```bash
lsof -i :8765        # find what's using it
kill -9 <PID>
```

---

## Performance notes

- FaceMesh at 640×480 / 15 fps typically uses **5–15% CPU** on a 2020+ laptop
- `refine_landmarks=False` skips iris landmark refinement (saves ~30% compute)
- The rolling window uses O(1) running sums — no per-poll recomputation
- The daemon thread exits automatically when the FastAPI process stops
