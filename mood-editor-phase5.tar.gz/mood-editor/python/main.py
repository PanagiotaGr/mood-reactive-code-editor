"""
python/main.py
──────────────────────────────────────────────────────────────────────────────
Mood-Reactive Editor — local inference service (Phase 4)

Privacy: no frames are stored or transmitted.  All processing is in-memory.

Start:
    uvicorn main:app --host 127.0.0.1 --port 8765 --reload

Endpoints
    GET  /health           liveness probe
    GET  /infer            latest stress reading (webcam or fallback)
    GET  /infer/batch      n readings for state-machine testing (stub only)
    POST /camera/start     begin webcam capture in background thread
    POST /camera/stop      stop webcam capture
    GET  /camera/status    current camera diagnostics

Schema (canonical, Phase 4+)
    stress_score  int   0-100   (canonical)
    state         str   "productive" | "neutral" | "stressed"
    source        str   "webcam" | "stub" | "fallback"
    signals       obj   debug signals (ear, brow, mouth) -- omitted in stub
    warning       str   present only when source != "webcam"
    timestamp_ms  int   unix ms
"""

from __future__ import annotations

import itertools
import logging
import random
import time
from typing import Any, Literal, Optional

from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

import inference  # local module

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s  %(message)s")
logger = logging.getLogger(__name__)

# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Mood-Reactive Editor — Inference Service",
    description=(
        "Local-only stress/mood inference. "
        "No frames or personal data leave this machine."
    ),
    version="0.4.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["vscode-webview://*", "http://localhost:*", "http://127.0.0.1:*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

_start_time = time.monotonic()

# ── Fallback stub cycle (preserved from Phase 2) ──────────────────────────────

_STATE_CYCLE: list[tuple[str, int, int]] = [
    # (state,        score_min, score_max)  -- 0-100 integers
    ("productive",   5,   30),
    ("productive",  10,   34),
    ("neutral",     35,   54),
    ("neutral",     40,   59),
    ("stressed",    65,   85),
    ("stressed",    70,   90),
    ("neutral",     45,   59),
    ("productive",   5,   25),
]
_cycler = itertools.cycle(enumerate(_STATE_CYCLE))


def _stub_reading(seed: int | None = None) -> dict[str, Any]:
    """Deterministic cycle reading used when camera is unavailable."""
    cycle_idx, (state, lo, hi) = next(_cycler)
    rng = random.Random(seed if seed is not None else random.randint(0, 2**32))
    score = rng.randint(lo, hi)
    return {
        "stress_score": score,
        "state":        state,
        "source":       "stub",
        "cycle_index":  cycle_idx,
        "timestamp_ms": int(time.time() * 1000),
        "warning":      "Camera not active -- returning deterministic stub",
    }


# ── Response models ───────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    ok: bool = True
    uptime_s: float
    version: str = "0.4.0"
    camera_running: bool


class SignalsModel(BaseModel):
    """Raw per-signal debug values. Absent in stub/fallback mode."""
    ear:            float = Field(description="Mean eye aspect ratio over window")
    brow:           float = Field(description="Mean brow-eye normalised distance")
    mouth:          float = Field(description="Mean lip gap normalised by face height")
    ear_stress:     float = Field(description="EAR-derived stress component 0-1")
    brow_stress:    float = Field(description="Brow-derived stress component 0-1")
    mouth_stress:   float = Field(description="Mouth-derived stress component 0-1")
    baseline_locked: float = Field(description="1.0 once 5 s baseline captured")
    window_n:       float = Field(description="Frame count in active window")


class InferResponse(BaseModel):
    stress_score: int = Field(
        ..., ge=0, le=100,
        description="Canonical stress score: 0 (calm) to 100 (stressed)",
    )
    state: Literal["productive", "neutral", "stressed"]
    source: Literal["webcam", "stub", "fallback"]
    signals: Optional[SignalsModel] = Field(
        default=None,
        description="Per-signal debug values; present only when source=webcam",
    )
    warning: Optional[str] = Field(
        default=None,
        description="Explanation when source is not webcam",
    )
    cycle_index: Optional[int] = Field(
        default=None,
        description="Stub cycle step (0-7); absent in webcam mode",
    )
    timestamp_ms: int


class CameraStatusResponse(BaseModel):
    running: bool
    error: Optional[str]
    frames_total: int
    faces_detected: int
    baseline_locked: bool
    last_frame_age_s: Optional[float]


class CameraActionResponse(BaseModel):
    ok: bool
    detail: str


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse, tags=["meta"])
def health() -> HealthResponse:
    """Liveness probe. Extension calls this on activation."""
    return HealthResponse(
        uptime_s=round(time.monotonic() - _start_time, 2),
        camera_running=inference.camera_running(),
    )


@app.get("/infer", response_model=InferResponse, tags=["mood"])
def infer(
    seed: int | None = Query(
        default=None,
        description="RNG seed for stub fallback. Ignored when camera is active.",
    ),
) -> InferResponse:
    """
    Return the latest stress reading.

    - Camera running + face visible    -> source=webcam
    - Camera running + no face         -> source=fallback + warning
    - Camera not started               -> source=stub (deterministic cycle)
    """
    if inference.camera_running():
        raw  = inference.latest_reading()
        sigs = raw.get("signals")
        return InferResponse(
            stress_score=raw["stress_score"],
            state=raw["state"],           # type: ignore[arg-type]
            source=raw["source"],         # type: ignore[arg-type]
            signals=SignalsModel(**sigs) if sigs and raw["source"] == "webcam" else None,
            warning=raw.get("warning"),
            timestamp_ms=raw["timestamp_ms"],
        )
    else:
        raw = _stub_reading(seed)
        return InferResponse(
            stress_score=raw["stress_score"],
            state=raw["state"],           # type: ignore[arg-type]
            source="stub",
            warning=raw.get("warning"),
            cycle_index=raw.get("cycle_index"),
            timestamp_ms=raw["timestamp_ms"],
        )


@app.get("/infer/batch", response_model=list[InferResponse], tags=["mood"])
def infer_batch(
    n: int = Query(default=8, ge=1, le=64),
    seed: int | None = Query(default=42),
) -> list[InferResponse]:
    """
    Return n stub readings in one call.
    Always uses stub mode regardless of camera state -- handy for TS unit tests.
    """
    results = []
    for i in range(n):
        s = (seed + i) if seed is not None else None
        raw = _stub_reading(s)
        results.append(InferResponse(
            stress_score=raw["stress_score"],
            state=raw["state"],           # type: ignore[arg-type]
            source="stub",
            warning=raw.get("warning"),
            cycle_index=raw.get("cycle_index"),
            timestamp_ms=raw["timestamp_ms"],
        ))
    return results


@app.post("/camera/start", response_model=CameraActionResponse, tags=["camera"])
def camera_start() -> CameraActionResponse:
    """
    Begin webcam capture in a background daemon thread.

    The thread reads frames at ~15 fps, extracts FaceMesh landmarks,
    computes EAR / brow / mouth signals, and feeds them into a 15 s
    rolling window.  No frames are retained after landmark extraction.

    Idempotent -- safe to call when camera is already running.
    """
    result = inference.camera_start()
    if result.get("started"):
        return CameraActionResponse(ok=True, detail="Camera capture started")
    return CameraActionResponse(ok=False, detail=result.get("reason", "unknown"))


@app.post("/camera/stop", response_model=CameraActionResponse, tags=["camera"])
def camera_stop() -> CameraActionResponse:
    """Stop the webcam capture thread and release the camera device."""
    result = inference.camera_stop()
    if result.get("stopped"):
        return CameraActionResponse(ok=True, detail="Camera capture stopped")
    return CameraActionResponse(ok=False, detail=result.get("reason", "unknown"))


@app.get("/camera/status", response_model=CameraStatusResponse, tags=["camera"])
def camera_status() -> CameraStatusResponse:
    """Diagnostic endpoint -- baseline lock, frame counts, error state."""
    from inference import _cam_state, _cam_lock  # noqa: PLC0415
    import time as _time
    with _cam_lock:
        running        = _cam_state.running
        error          = _cam_state.error
        frames_total   = _cam_state.frames_total
        faces_detected = _cam_state.faces_detected
        last_ts        = _cam_state.last_frame_ts
        baseline       = _cam_state.window.has_baseline

    age = round(_time.monotonic() - last_ts, 2) if last_ts else None
    return CameraStatusResponse(
        running=running,
        error=error,
        frames_total=frames_total,
        faces_detected=faces_detected,
        baseline_locked=baseline,
        last_frame_age_s=age,
    )
