// src/extension.ts
// ─────────────────────────────────────────────────────────
// Extension entry point.  Phase 1 wires up:
//   • ThemeManager  – switches color theme per state
//   • StatusBarController – live status bar item
//   • Manual override commands (setCalm / setFocused / setStressed)
//   • toggleMonitoring stub (real poller added in Phase 3)
//   • showDashboard stub (Webview added later)

import * as vscode from "vscode";
import { MoodState, MoodReading } from "./types";
import { ThemeManager } from "./themeManager";
import { StatusBarController } from "./statusBar";

// ── Module-level singletons ───────────────────────────────
let themeManager: ThemeManager;
let statusBar: StatusBarController;
let monitoringActive = false;

// ── Helpers ───────────────────────────────────────────────

/** Build a synthetic MoodReading from a manual state choice */
function manualReading(state: MoodState): MoodReading {
  const scoreMap: Record<MoodState, number> = {
    [MoodState.Calm]: 0.1,
    [MoodState.Focused]: 0.45,
    [MoodState.Stressed]: 0.8,
  };
  return {
    stress_score: scoreMap[state],
    state,
    timestamp: Date.now(),
    source: "manual",
  };
}

/** Apply a mood state immediately (theme + status bar) */
async function applyMood(reading: MoodReading): Promise<void> {
  await themeManager.applyState(reading.state);
  statusBar.update(reading);
}

// ── Activation ────────────────────────────────────────────

export async function activate(ctx: vscode.ExtensionContext): Promise<void> {
  themeManager = new ThemeManager();
  statusBar = new StatusBarController();

  // ── Commands ──────────────────────────────────────────

  ctx.subscriptions.push(
    vscode.commands.registerCommand("moodEditor.setCalm", async () => {
      const r = manualReading(MoodState.Calm);
      await applyMood(r);
      vscode.window.showInformationMessage("Mood Editor → Calm 😌");
    }),

    vscode.commands.registerCommand("moodEditor.setFocused", async () => {
      const r = manualReading(MoodState.Focused);
      await applyMood(r);
      vscode.window.showInformationMessage("Mood Editor → Focused ⚡");
    }),

    vscode.commands.registerCommand("moodEditor.setStressed", async () => {
      const r = manualReading(MoodState.Stressed);
      await applyMood(r);
      vscode.window.showInformationMessage("Mood Editor → Stressed 🔥");
    }),

    vscode.commands.registerCommand(
      "moodEditor.toggleMonitoring",
      async () => {
        monitoringActive = !monitoringActive;
        statusBar.setMonitoring(monitoringActive);

        if (monitoringActive) {
          vscode.window.showInformationMessage(
            "Mood Editor: Monitoring ON — Python service will be polled every 2 s (Phase 3+)"
          );
        } else {
          vscode.window.showInformationMessage(
            "Mood Editor: Monitoring OFF"
          );
        }
      }
    ),

    vscode.commands.registerCommand("moodEditor.showDashboard", () => {
      // Full Webview dashboard is a later phase; for now show a quick-pick
      const state = themeManager.getCurrentState();
      const label = state
        ? `Current mood: ${state}`
        : "No mood set yet — use Command Palette to set a state.";

      vscode.window.showQuickPick(
        [
          { label: "$(smiley)  Set Calm", id: "moodEditor.setCalm" },
          { label: "$(zap)  Set Focused", id: "moodEditor.setFocused" },
          { label: "$(flame)  Set Stressed", id: "moodEditor.setStressed" },
          {
            label: "$(pulse)  Toggle Monitoring",
            id: "moodEditor.toggleMonitoring",
          },
        ],
        { placeHolder: label }
      ).then((picked) => {
        if (picked) {
          vscode.commands.executeCommand(
            (picked as { label: string; id: string }).id
          );
        }
      });
    }),

    // Dispose status bar on deactivation
    statusBar
  );

  // ── Startup feedback ──────────────────────────────────
  vscode.window.showInformationMessage(
    "Mood-Reactive Editor activated 🧠 — use the Command Palette (Mood Editor: …) to get started."
  );
}

export function deactivate(): void {
  monitoringActive = false;
}
