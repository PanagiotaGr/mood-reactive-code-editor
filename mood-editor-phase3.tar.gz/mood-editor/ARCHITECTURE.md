# Mood-Reactive Code Editor — Architecture

## Overview

A VS Code extension that detects developer stress in real-time via webcam
facial heuristics, adapts the editor theme, plays ambient audio, and
surfaces context-sensitive task difficulty suggestions.

---

## System Diagram

```
┌─────────────────────────────────────────────────────┐
│                  VS Code Extension                   │
│                                                      │
│  ┌──────────────┐   ┌────────────────────────────┐  │
│  │ ThemeManager │   │    StatusBarController      │  │
│  └──────┬───────┘   └────────────┬───────────────┘  │
│         │                        │                   │
│  ┌──────▼────────────────────────▼───────────────┐  │
│  │              MoodEngine (Phase 3)              │  │
│  │   EMA smoother + hysteresis state machine      │  │
│  └──────────────────────┬────────────────────────┘  │
│                         │ HTTP (localhost:8765)       │
└─────────────────────────┼───────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────┐
│             Python FastAPI Service (Phase 2+)        │
│                                                      │
│  GET /mood  →  { stress_score, state, timestamp }   │
│                                                      │
│  ┌──────────────────────────────────────────────┐   │
│  │       WebcamAnalyzer (Phase 4)               │   │
│  │   mediapipe FaceMesh → landmark deltas       │   │
│  │   → brow furrow, eye aperture, jaw tension   │   │
│  │   → normalized stress_score 0.0–1.0          │   │
│  └──────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────┘
```

---

## Folder Structure

```
mood-reactive-editor/
├── .vscode/
│   ├── launch.json          # F5 debug config
│   └── tasks.json           # tsc watch build task
│
├── src/                     # TypeScript source (compiled → out/)
│   ├── extension.ts         # activate() / deactivate() entry point
│   ├── types.ts             # MoodState enum, MoodReading, ThemeMap, …
│   ├── themeManager.ts      # Applies VS Code color themes per state
│   ├── statusBar.ts         # Status bar item controller
│   ├── moodEngine.ts        # EMA + hysteresis state machine (Phase 3)
│   ├── serviceClient.ts     # HTTP client → Python service (Phase 3)
│   ├── audioPlayer.ts       # Ambient audio via VS Code API (Phase 5)
│   └── suggestionProvider.ts# Inline task-difficulty hints (Phase 5)
│
├── python/                  # Local Python micro-service
│   ├── main.py              # FastAPI app, /mood endpoint (Phase 2)
│   ├── webcam_analyzer.py   # mediapipe FaceMesh heuristics (Phase 4)
│   └── requirements.txt
│
├── media/                   # Bundled audio files (Phase 5)
│   ├── calm.mp3
│   ├── focused.mp3
│   └── stressed.mp3
│
├── themes/                  # (reserved) custom theme JSON overrides
├── package.json
├── tsconfig.json
└── ARCHITECTURE.md
```

---

## State Machine

```
              stress < calmToFocused (0.25)
    ┌─────────────────────────────────────┐
    │                                     ▼
  STRESSED ──────────────────────────► CALM
    ▲         stress < stressedToFocused   │
    │               (0.50)               │
    │                                    │
    │        stress > focusedToStressed  │ stress > calmToFocused
    └──────────────── FOCUSED ◄──────────┘
                          │          (0.35)
                          │
              (EMA-smoothed score, α=0.3, polled every 2 s)
```

### Hysteresis design
Two thresholds per transition prevent rapid oscillation:
- Entering STRESSED requires score > 0.65
- Leaving  STRESSED requires score < 0.50  ← dead-band gap

---

## Phase Roadmap

| Phase | Deliverable |
|-------|-------------|
| 1 | Extension scaffold, ThemeManager, StatusBar, manual commands |
| 2 | Python FastAPI stub at :8765 returning random stress_score |
| 3 | serviceClient.ts + moodEngine.ts (EMA + hysteresis), 2 s poll |
| 4 | webcam_analyzer.py (mediapipe FaceMesh), real stress scores |
| 5 | audioPlayer.ts (ambient loops), suggestionProvider.ts (hints) |

---

## Key Design Decisions

1. **Local-only** — no data ever leaves the machine; webcam frames are
   processed in-process by mediapipe and only the scalar score is sent.

2. **EMA smoothing** — raw frame-by-frame scores are noisy; α=0.3 gives
   a ~3-sample smoothing window that reacts in ~6 s.

3. **Hysteresis** — prevents theme flicker when score hovers near a boundary.

4. **Configurable thresholds** — all numbers live in VS Code settings so
   users can tune sensitivity without touching code.

5. **Graceful degradation** — if the Python service is unreachable the
   extension silently falls back to the last known state (no crash, no spam).
