// src/moodEngine.ts
// ─────────────────────────────────────────────────────────────────────────────
// MoodEngine — the brain of the extension.
//
// Combines:
//   1. Exponential Moving Average (EMA) smoothing of raw stress scores
//   2. Hysteresis state machine that prevents rapid oscillation
//   3. Periodic polling of the Python service via ServiceClient
//   4. Propagation of state changes to ThemeManager + StatusBarController
//
// State-machine transitions (threshold names from settings):
//
//   CALM ──(score > calmToFocused)──► FOCUSED
//   FOCUSED ──(score > focusedToStressed)──► STRESSED
//   STRESSED ──(score < stressedToFocused)──► FOCUSED
//   FOCUSED ──(score < focusedToCalm)──► CALM
//
// The dead-band between paired thresholds (e.g. 0.65 enter / 0.50 exit)
// prevents the theme from flickering when the score hovers near a boundary.

import * as vscode from "vscode";
import { MoodState, MoodReading, HysteresisThresholds } from "./types";
import { ServiceClient } from "./serviceClient";
import { ThemeManager } from "./themeManager";
import { StatusBarController } from "./statusBar";

// ── Types ─────────────────────────────────────────────────────────────────────

export type EngineStatus = "idle" | "running" | "offline";

export interface EngineState {
  status: EngineStatus;
  currentMoodState: MoodState;
  smoothedScore: number;       // EMA-filtered score, 0–1
  lastRawScore: number;        // Most recent unfiltered score from service
  consecutiveErrors: number;
  lastSuccessMs: number | null;
}

// ── Engine ────────────────────────────────────────────────────────────────────

export class MoodEngine implements vscode.Disposable {
  private _status: EngineStatus = "idle";
  private _moodState: MoodState = MoodState.Focused; // safe neutral default
  private _ema: number = 0.5;                         // start at mid-range
  private _lastRaw: number = 0.5;
  private _consecutiveErrors = 0;
  private _lastSuccessMs: number | null = null;

  private _pollTimer: ReturnType<typeof setInterval> | null = null;

  // Emit one notification per offline/online transition — never spam
  private _offlineNotified = false;

  private readonly _client: ServiceClient;
  private readonly _themeManager: ThemeManager;
  private readonly _statusBar: StatusBarController;

  // Event emitter so extension.ts (and future panels) can react
  private readonly _onStateChange = new vscode.EventEmitter<MoodReading>();
  readonly onStateChange: vscode.Event<MoodReading> = this._onStateChange.event;

  constructor(
    client: ServiceClient,
    themeManager: ThemeManager,
    statusBar: StatusBarController
  ) {
    this._client = client;
    this._themeManager = themeManager;
    this._statusBar = statusBar;
  }

  // ── Public API ────────────────────────────────────────────────────────────

  get status(): EngineStatus { return this._status; }
  get engineState(): EngineState {
    return {
      status: this._status,
      currentMoodState: this._moodState,
      smoothedScore: this._ema,
      lastRawScore: this._lastRaw,
      consecutiveErrors: this._consecutiveErrors,
      lastSuccessMs: this._lastSuccessMs,
    };
  }

  /**
   * Start polling.  Performs a health-check first; if the service is down,
   * the engine still starts but immediately shows "offline" in the status bar.
   */
  async start(): Promise<void> {
    if (this._status === "running") { return; }

    this._status = "running";
    this._consecutiveErrors = 0;

    // ── Health check on startup ──────────────────────────────────────────
    const healthy = await this._client.health();
    if (!healthy) {
      this._handleOffline();
    }

    // ── Start recurring poller ───────────────────────────────────────────
    const intervalMs = this._pollInterval();
    this._pollTimer = setInterval(() => this._tick(), intervalMs);

    // First tick immediately so there's no blank delay
    await this._tick();
  }

  /** Stop polling and reset status bar to idle. */
  stop(): void {
    if (this._pollTimer !== null) {
      clearInterval(this._pollTimer);
      this._pollTimer = null;
    }
    this._status = "idle";
    this._offlineNotified = false;
    this._statusBar.setIdle();
  }

  dispose(): void {
    this.stop();
    this._onStateChange.dispose();
  }

  // ── Private: poll tick ────────────────────────────────────────────────────

  private async _tick(): Promise<void> {
    if (this._status !== "running") { return; }

    const reading = await this._client.infer();

    if (reading === null) {
      this._consecutiveErrors++;
      this._handleOffline();
      return;
    }

    // Service is (back) online
    if (this._consecutiveErrors > 0) {
      this._handleOnline();
    }
    this._consecutiveErrors = 0;
    this._lastSuccessMs = Date.now();
    this._offlineNotified = false;

    // ── EMA smoothing ────────────────────────────────────────────────────
    const alpha = this._emaAlpha();
    this._lastRaw = reading.stress_score;
    this._ema = alpha * reading.stress_score + (1 - alpha) * this._ema;

    // ── Hysteresis state machine ─────────────────────────────────────────
    const newState = this._nextState(this._ema);
    const stateChanged = newState !== this._moodState;
    this._moodState = newState;

    // Build enriched reading (smoothed score + resolved state)
    const smoothedReading: MoodReading = {
      ...reading,
      stress_score: this._ema,
      state: newState,
    };

    // ── Side effects ─────────────────────────────────────────────────────
    this._statusBar.update(smoothedReading);

    if (stateChanged) {
      await this._themeManager.applyState(newState);
      this._onStateChange.fire(smoothedReading);
    }
  }

  // ── Private: state machine ────────────────────────────────────────────────

  /**
   * Pure function: given the current smoothed score and the existing state,
   * return the next state according to the hysteresis thresholds.
   */
  private _nextState(score: number): MoodState {
    const t = this._thresholds();
    const current = this._moodState;

    switch (current) {
      case MoodState.Calm:
        if (score > t.calmToFocused)    { return MoodState.Focused; }
        return MoodState.Calm;

      case MoodState.Focused:
        if (score > t.focusedToStressed) { return MoodState.Stressed; }
        if (score < t.focusedToCalm)     { return MoodState.Calm; }
        return MoodState.Focused;

      case MoodState.Stressed:
        if (score < t.stressedToFocused) { return MoodState.Focused; }
        return MoodState.Stressed;
    }
  }

  // ── Private: offline / online handling ───────────────────────────────────

  private _handleOffline(): void {
    this._statusBar.setOffline();

    // Show one notification — never spam
    if (!this._offlineNotified) {
      this._offlineNotified = true;
      vscode.window.showWarningMessage(
        "Mood Editor: Python service unreachable. " +
        "Start it with: `uvicorn main:app --port 8765` in the python/ directory. " +
        "Falling back to Focused state.",
        "Dismiss"
      );
    }

    // Fall back to neutral "focused" state without changing the theme
    // (we leave whatever theme was last applied — no jarring switch)
    this._moodState = MoodState.Focused;
  }

  private _handleOnline(): void {
    // Only log recovery — no toast to avoid noise
    console.log("[MoodEngine] Service reconnected after", this._consecutiveErrors, "errors");
    this._offlineNotified = false;
  }

  // ── Private: config helpers ───────────────────────────────────────────────

  private _pollInterval(): number {
    return vscode.workspace
      .getConfiguration("moodEditor")
      .get<number>("pollIntervalMs", 2000);
  }

  private _emaAlpha(): number {
    return vscode.workspace
      .getConfiguration("moodEditor")
      .get<number>("emaAlpha", 0.3);
  }

  private _thresholds(): HysteresisThresholds {
    const cfg = vscode.workspace.getConfiguration(
      "moodEditor.hysteresisThresholds"
    );
    return {
      calmToFocused:      cfg.get<number>("calmToFocused",      0.35),
      focusedToStressed:  cfg.get<number>("focusedToStressed",  0.65),
      stressedToFocused:  cfg.get<number>("stressedToFocused",  0.50),
      focusedToCalm:      cfg.get<number>("focusedToCalm",      0.25),
    };
  }
}
