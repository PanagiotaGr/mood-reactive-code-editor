// src/statusBar.ts
// ─────────────────────────────────────────────────────────
// Manages the VS Code status-bar item that shows mood state + score.

import * as vscode from "vscode";
import { MoodState, MoodReading } from "./types";

const STATE_ICONS: Record<MoodState, string> = {
  [MoodState.Calm]: "$(smiley)",
  [MoodState.Focused]: "$(zap)",
  [MoodState.Stressed]: "$(flame)",
};

const STATE_COLORS: Record<MoodState, vscode.ThemeColor> = {
  [MoodState.Calm]: new vscode.ThemeColor("statusBarItem.prominentBackground"),
  [MoodState.Focused]: new vscode.ThemeColor("statusBarItem.activeBackground"),
  [MoodState.Stressed]: new vscode.ThemeColor("statusBarItem.errorBackground"),
};

export class StatusBarController implements vscode.Disposable {
  private readonly item: vscode.StatusBarItem;

  constructor() {
    // Right side, high priority so it stays visible
    this.item = vscode.window.createStatusBarItem(
      vscode.StatusBarAlignment.Right,
      1000
    );
    this.item.command = "moodEditor.showDashboard";
    this.item.tooltip = "Mood-Reactive Editor — click for dashboard";
    this.setIdle();
    this.item.show();
  }

  /** Called when monitoring is off / not yet started */
  setIdle(): void {
    this.item.text = "$(pulse) Mood: —";
    this.item.backgroundColor = undefined;
    this.item.color = undefined;
  }

  /** Called when monitoring is actively running */
  setMonitoring(active: boolean): void {
    if (!active) {
      this.setIdle();
    }
    // Actual state updates come via update()
  }

  /** Called when the Python service is unreachable */
  setOffline(): void {
    this.item.text = "$(warning) Mood: offline";
    this.item.backgroundColor = new vscode.ThemeColor(
      "statusBarItem.warningBackground"
    );
    this.item.color = undefined;
  }

  /** Main update path — called whenever a new reading arrives */
  update(reading: MoodReading): void {
    const { state, stress_score } = reading;
    const icon = STATE_ICONS[state];
    const pct = Math.round(stress_score * 100);
    this.item.text = `${icon} Mood: ${state} (${pct}%)`;
    this.item.backgroundColor = STATE_COLORS[state];
  }

  dispose(): void {
    this.item.dispose();
  }
}
