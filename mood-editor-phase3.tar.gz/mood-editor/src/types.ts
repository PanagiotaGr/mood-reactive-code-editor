// src/types.ts
// ─────────────────────────────────────────────────────────
// Shared types used across the extension

export enum MoodState {
  Calm = "calm",
  Focused = "focused",
  Stressed = "stressed",
}

export interface MoodReading {
  stress_score: number;   // 0.0 (calm) → 1.0 (stressed)
  state: MoodState;       // raw label from the service
  timestamp: number;      // Unix ms
  source: "manual" | "service" | "stub";
}

export interface ThemeMap {
  [MoodState.Calm]: string;
  [MoodState.Focused]: string;
  [MoodState.Stressed]: string;
}

export interface HysteresisThresholds {
  calmToFocused: number;
  focusedToStressed: number;
  stressedToFocused: number;
  focusedToCalm: number;
}
