// src/themeManager.ts
// ─────────────────────────────────────────────────────────
// Responsible for applying VS Code color themes keyed to mood states.

import * as vscode from "vscode";
import { MoodState, ThemeMap } from "./types";

export class ThemeManager {
  private currentState: MoodState | null = null;

  /** Returns the configured theme name for a given state */
  private getThemeForState(state: MoodState): string {
    const cfg = vscode.workspace.getConfiguration("moodEditor.themes");
    const defaults: ThemeMap = {
      [MoodState.Calm]: "GitHub Light",
      [MoodState.Focused]: "One Dark Pro",
      [MoodState.Stressed]: "Solarized Dark",
    };
    return cfg.get<string>(state) ?? defaults[state];
  }

  /**
   * Switches the VS Code color theme to match the given mood state.
   * No-ops if the state has not changed (avoids flicker).
   */
  async applyState(state: MoodState): Promise<void> {
    if (state === this.currentState) {
      return;
    }

    const themeName = this.getThemeForState(state);
    const cfg = vscode.workspace.getConfiguration("workbench");

    try {
      await cfg.update(
        "colorTheme",
        themeName,
        vscode.ConfigurationTarget.Global
      );
      this.currentState = state;
    } catch (err) {
      // Theme may not be installed — surface a gentle warning
      vscode.window.showWarningMessage(
        `Mood Editor: Theme "${themeName}" not found for state "${state}". ` +
          `Install it or update moodEditor.themes.${state} in settings.`
      );
    }
  }

  getCurrentState(): MoodState | null {
    return this.currentState;
  }
}
