// src/serviceClient.ts
// ─────────────────────────────────────────────────────────────────────────────
// Thin HTTP client for the local Python inference service.
//
// Responsibilities
//   • health()  — GET /health, used at startup to verify service is up
//   • infer()   — GET /infer, returns a normalised MoodReading or null
//
// Normalisation contract
//   Python response may carry either:
//     • stress_score  (float 0–1)   ← preferred
//     • stress_pct    (int 0–100)   ← fallback
//   Python `state` vocabulary → MoodState mapping:
//     productive → MoodState.Calm
//     neutral    → MoodState.Focused
//     stressed   → MoodState.Stressed
//
// Network errors are caught and returned as null so callers can
// handle "offline" without crashing or spamming notifications.

import * as vscode from "vscode";
import { MoodState, MoodReading } from "./types";

// ── Python response shape (permissive) ────────────────────────────────────────

interface RawInferResponse {
  stress_score?: number;   // 0.0–1.0
  stress_pct?: number;     // 0–100
  state?: string;          // "productive" | "neutral" | "stressed"
  timestamp_ms?: number;
  source?: string;
}

interface RawHealthResponse {
  ok?: boolean;
  uptime_s?: number;
}

// ── State vocabulary map ──────────────────────────────────────────────────────

const PYTHON_STATE_MAP: Record<string, MoodState> = {
  productive: MoodState.Calm,
  neutral:    MoodState.Focused,
  stressed:   MoodState.Stressed,
  // Pass-through in case future phases emit these directly
  calm:       MoodState.Calm,
  focused:    MoodState.Focused,
};

// ── Client ────────────────────────────────────────────────────────────────────

export class ServiceClient {
  private get baseUrl(): string {
    return vscode.workspace
      .getConfiguration("moodEditor")
      .get<string>("pythonServiceUrl", "http://localhost:8765");
  }

  /**
   * Attempt GET /health.
   * Returns true if the service is reachable and reports ok:true.
   * Returns false on any network or parse error.
   */
  async health(): Promise<boolean> {
    try {
      const res = await this._fetch("/health");
      if (!res.ok) { return false; }
      const body: RawHealthResponse = await res.json();
      return body.ok === true;
    } catch {
      return false;
    }
  }

  /**
   * Attempt GET /infer.
   * Returns a normalised MoodReading on success, or null on any failure.
   * Callers must treat null as "service offline / reading unavailable".
   */
  async infer(): Promise<MoodReading | null> {
    try {
      const res = await this._fetch("/infer");
      if (!res.ok) { return null; }

      const raw: RawInferResponse = await res.json();
      return this._normalise(raw);
    } catch {
      return null;
    }
  }

  // ── Private helpers ──────────────────────────────────────────────────────

  /** Thin fetch wrapper with a short timeout so the poller never hangs. */
  private async _fetch(path: string): Promise<Response> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 1500); // 1.5 s hard timeout
    try {
      return await fetch(`${this.baseUrl}${path}`, {
        signal: controller.signal,
        headers: { Accept: "application/json" },
      });
    } finally {
      clearTimeout(timer);
    }
  }

  /** Convert a raw Python response into a typed MoodReading. */
  private _normalise(raw: RawInferResponse): MoodReading {
    // ── Score normalisation: prefer stress_score (0–1), fall back to stress_pct
    let score: number;
    if (typeof raw.stress_score === "number") {
      score = Math.max(0, Math.min(1, raw.stress_score));
    } else if (typeof raw.stress_pct === "number") {
      score = Math.max(0, Math.min(100, raw.stress_pct)) / 100;
    } else {
      score = 0.5; // unknown — default to mid-range
    }

    // ── State mapping
    const rawState = (raw.state ?? "neutral").toLowerCase().trim();
    const state: MoodState = PYTHON_STATE_MAP[rawState] ?? MoodState.Focused;

    return {
      stress_score: score,
      state,
      timestamp: raw.timestamp_ms ?? Date.now(),
      source: "service",
    };
  }
}
