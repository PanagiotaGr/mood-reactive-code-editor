// src/extension.ts
// ─────────────────────────────────────────────────────────────────────────────
// Extension entry point.
//
// Phase 3 additions (on top of Phase 1):
//   • ServiceClient  — typed HTTP client for the Python FastAPI service
//   • MoodEngine     — EMA smoother + hysteresis state machine + poller
//   • toggleMonitoring now actually starts/stops the engine
//   • Manual override commands apply state instantly (bypass EMA)
//   • showDashboard quick-pick now shows live engine diagnostics

import * as vscode from "vscode";
import { MoodState, MoodReading } from "./types";
import { ThemeManager } from "./themeManager";
import { StatusBarController } from "./statusBar";
import { ServiceClient } from "./serviceClient";
import { MoodEngine } from "./moodEngine";

// ── Module-level singletons ───────────────────────────────────────────────────

let themeManager: ThemeManager;
let statusBar: StatusBarController;
let serviceClient: ServiceClient;
let moodEngine: MoodEngine;

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Representative stress scores for manual overrides */
const MANUAL_SCORES: Record<MoodState, number> = {
  [MoodState.Calm]:     0.1,
  [MoodState.Focused]:  0.45,
  [MoodState.Stressed]: 0.8,
};

function manualReading(state: MoodState): MoodReading {
  return {
    stress_score: MANUAL_SCORES[state],
    state,
    timestamp: Date.now(),
    source: "manual",
  };
}

/** Apply mood immediately (bypasses EMA — manual overrides are instant). */
async function applyMoodManual(reading: MoodReading): Promise<void> {
  await themeManager.applyState(reading.state);
  statusBar.update(reading);
}

/** Format engine diagnostics for the dashboard quick-pick placeholder. */
function engineSummary(): string {
  const s = moodEngine.engineState;
  if (s.status === "idle") {
    return "Monitoring OFF — Toggle Monitoring to start";
  }
  if (s.status === "offline") {
    return `⚠ Service offline (${s.consecutiveErrors} errors) — state: ${s.currentMoodState}`;
  }
  const pct    = Math.round(s.smoothedScore * 100);
  const rawPct = Math.round(s.lastRawScore  * 100);
  return `● ${s.currentMoodState}  smoothed=${pct}%  raw=${rawPct}%`;
}

// ── Activation ────────────────────────────────────────────────────────────────

export async function activate(ctx: vscode.ExtensionContext): Promise<void> {
  // ── Instantiate singletons ──────────────────────────────────────────────
  themeManager  = new ThemeManager();
  statusBar     = new StatusBarController();
  serviceClient = new ServiceClient();
  moodEngine    = new MoodEngine(serviceClient, themeManager, statusBar);

  // ── Commands ────────────────────────────────────────────────────────────

  ctx.subscriptions.push(
    // ── Manual state overrides ────────────────────────────────────────────
    vscode.commands.registerCommand("moodEditor.setCalm", async () => {
      await applyMoodManual(manualReading(MoodState.Calm));
      vscode.window.showInformationMessage("Mood Editor → Calm 😌");
    }),

    vscode.commands.registerCommand("moodEditor.setFocused", async () => {
      await applyMoodManual(manualReading(MoodState.Focused));
      vscode.window.showInformationMessage("Mood Editor → Focused ⚡");
    }),

    vscode.commands.registerCommand("moodEditor.setStressed", async () => {
      await applyMoodManual(manualReading(MoodState.Stressed));
      vscode.window.showInformationMessage("Mood Editor → Stressed 🔥");
    }),

    // ── Monitoring toggle ─────────────────────────────────────────────────
    vscode.commands.registerCommand(
      "moodEditor.toggleMonitoring",
      async () => {
        const isRunning = moodEngine.status === "running";

        if (isRunning) {
          moodEngine.stop();
          vscode.window.showInformationMessage("Mood Editor: Monitoring OFF ⏹");
        } else {
          await moodEngine.start();
          const pollMs = vscode.workspace
            .getConfiguration("moodEditor")
            .get<number>("pollIntervalMs", 2000);
          vscode.window.showInformationMessage(
            `Mood Editor: Monitoring ON ▶  polling every ${pollMs} ms`
          );
        }
      }
    ),

    // ── Dashboard (quick-pick) ────────────────────────────────────────────
    vscode.commands.registerCommand("moodEditor.showDashboard", () => {
      type DashItem = vscode.QuickPickItem & { id: string };

      const isRunning   = moodEngine.status === "running";
      const toggleLabel = isRunning
        ? "$(debug-stop)  Stop Monitoring"
        : "$(play)  Start Monitoring";

      const items: DashItem[] = [
        { label: "$(smiley)  Set Calm",    id: "moodEditor.setCalm"          },
        { label: "$(zap)  Set Focused",    id: "moodEditor.setFocused"       },
        { label: "$(flame)  Set Stressed", id: "moodEditor.setStressed"      },
        { label: toggleLabel,              id: "moodEditor.toggleMonitoring" },
      ];

      vscode.window.showQuickPick(items, {
        placeHolder: engineSummary(),
        title: "Mood-Reactive Editor",
      }).then((picked) => {
        if (picked) {
          vscode.commands.executeCommand(picked.id);
        }
      });
    }),

    // ── Cleanup ───────────────────────────────────────────────────────────
    moodEngine,   // dispose() stops the poller
    statusBar,    // dispose() removes the status bar item
  );

  // ── Startup feedback ────────────────────────────────────────────────────
  vscode.window.showInformationMessage(
    "Mood-Reactive Editor activated 🧠  — open Command Palette and run " +
    "\"Mood Editor: Toggle Monitoring\" to start live detection."
  );
}

export function deactivate(): void {
  // moodEngine.dispose() is called automatically via ctx.subscriptions
}
