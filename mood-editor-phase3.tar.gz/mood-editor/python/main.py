"""
python/main.py
──────────────────────────────────────────────────────────────────────────────
Mood-Reactive Editor — local inference service (Phase 2 stub)

Runs entirely on localhost:8765.  No external network calls are made.
All webcam/ML logic lives in webcam_analyzer.py (Phase 4); this stub
returns controlled random values so the VS Code extension can be tested
end-to-end without a camera.

Start:
    uvicorn main:app --host 127.0.0.1 --port 8765 --reload
"""

from __future__ import annotations

import itertools
import random
import time
from typing import Literal

from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# ── App setup ─────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Mood-Reactive Editor — Inference Service",
    description="Local-only stress/mood inference stub.  No data leaves this machine.",
    version="0.2.0",
)

# VS Code extension talks to localhost — allow it via CORS so a future
# WebView panel can also hit this endpoint directly from a browser context.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["vscode-webview://*", "http://localhost:*", "http://127.0.0.1:*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)

# ── State cycling (deterministic for testing) ─────────────────────────────────

# Predefined stress-score bands mapped to states.
# The cycler walks through these in order so tests can assert transitions.
_STATE_CYCLE: list[tuple[str, float, float]] = [
    # (state,          score_min, score_max)
    ("productive",     0.05,      0.30),
    ("productive",     0.10,      0.35),
    ("neutral",        0.35,      0.55),
    ("neutral",        0.40,      0.60),
    ("stressed",       0.65,      0.85),
    ("stressed",       0.70,      0.90),
    ("neutral",        0.45,      0.60),
    ("productive",     0.05,      0.25),
]

_cycler = itertools.cycle(enumerate(_STATE_CYCLE))

# Optional fixed seed exposed via query param for CI / snapshot tests.
_DEFAULT_SEED = 42


# ── Response models ────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    ok: bool = True
    uptime_s: float = Field(..., description="Seconds since service started")
    version: str = "0.2.0"


class InferResponse(BaseModel):
    stress_score: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="Normalised stress score 0.0 (calm) → 1.0 (stressed)",
    )
    stress_pct: int = Field(
        ...,
        ge=0,
        le=100,
        description="stress_score expressed as 0–100 integer (convenience field)",
    )
    state: Literal["productive", "neutral", "stressed"]
    cycle_index: int = Field(..., description="Which step of the test cycle we're on (0-based)")
    source: Literal["stub", "webcam"] = "stub"
    timestamp_ms: int = Field(..., description="Unix timestamp in milliseconds")


# ── Internal helpers ───────────────────────────────────────────────────────────

_start_time = time.monotonic()


def _next_reading(seed: int | None) -> InferResponse:
    """Advance the cycle and return a reading, optionally seeded."""
    cycle_idx, (state, lo, hi) = next(_cycler)

    rng = random.Random(seed if seed is not None else random.randint(0, 2**32))
    score = round(rng.uniform(lo, hi), 4)

    return InferResponse(
        stress_score=score,
        stress_pct=int(score * 100),
        state=state,           # type: ignore[arg-type]
        cycle_index=cycle_idx,
        source="stub",
        timestamp_ms=int(time.time() * 1000),
    )


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse, tags=["meta"])
def health() -> HealthResponse:
    """Liveness probe — VS Code extension calls this on startup."""
    return HealthResponse(uptime_s=round(time.monotonic() - _start_time, 2))


@app.get("/infer", response_model=InferResponse, tags=["mood"])
def infer(
    seed: int | None = Query(
        default=None,
        description=(
            "Optional RNG seed for reproducible scores. "
            "Omit for pseudo-random output. "
            "Pass seed=42 in CI / automated tests."
        ),
    ),
) -> InferResponse:
    """
    Return a stress reading.

    **Stub behaviour (Phase 2)**
    Cycles deterministically through 8 predefined (state, score-band) pairs so
    callers can observe all three states without waiting for real webcam data.

    **Phase 4+**
    When `webcam_analyzer.py` is active the `source` field changes to `"webcam"`
    and scores are derived from mediapipe FaceMesh landmarks.
    """
    return _next_reading(seed)


@app.get("/infer/batch", response_model=list[InferResponse], tags=["mood"])
def infer_batch(
    n: int = Query(default=8, ge=1, le=64, description="Number of readings to return"),
    seed: int | None = Query(default=_DEFAULT_SEED, description="Base RNG seed"),
) -> list[InferResponse]:
    """
    Return *n* readings in one call — useful for testing the state machine
    without having to poll /infer repeatedly.
    """
    results = []
    for i in range(n):
        s = (seed + i) if seed is not None else None
        results.append(_next_reading(s))
    return results
