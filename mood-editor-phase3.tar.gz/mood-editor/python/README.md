# Mood-Reactive Editor — Python Inference Service

Local-only FastAPI micro-service.  
**No data leaves your machine.**  Webcam frames never touch a network.

---

## Requirements

| Tool | Version |
|------|---------|
| Python | 3.11 + |
| pip | any recent |

---

## Setup

```bash
cd mood-reactive-editor/python

# 1. Create an isolated environment (recommended)
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
```

---

## Running the service

```bash
# Development (auto-reload on file save)
uvicorn main:app --host 127.0.0.1 --port 8765 --reload

# Production / background
uvicorn main:app --host 127.0.0.1 --port 8765
```

The service binds to **localhost only** — it is not reachable from other machines.

---

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Liveness probe — returns `{ ok: true, uptime_s, version }` |
| GET | `/infer` | Single mood reading — `{ stress_score, stress_pct, state, … }` |
| GET | `/infer?seed=42` | Same, but with a fixed RNG seed (reproducible for tests) |
| GET | `/infer/batch?n=8&seed=42` | 8 readings in one call — great for state-machine testing |
| GET | `/docs` | Auto-generated Swagger UI (FastAPI built-in) |
| GET | `/redoc` | ReDoc alternative docs |

### Sample `/infer` response

```json
{
  "stress_score": 0.1823,
  "stress_pct": 18,
  "state": "productive",
  "cycle_index": 0,
  "source": "stub",
  "timestamp_ms": 1712000000000
}
```

### State vocabulary

| Service state | Maps to extension MoodState |
|---------------|-----------------------------|
| `productive`  | `calm`                      |
| `neutral`     | `focused`                   |
| `stressed`    | `stressed`                  |

> The mapping lives in `src/serviceClient.ts` (Phase 3).

---

## Deterministic test cycle

The stub cycles through **8 predefined bands** in order:

| Step | State | Score range |
|------|-------|-------------|
| 0 | productive | 0.05 – 0.30 |
| 1 | productive | 0.10 – 0.35 |
| 2 | neutral    | 0.35 – 0.55 |
| 3 | neutral    | 0.40 – 0.60 |
| 4 | stressed   | 0.65 – 0.85 |
| 5 | stressed   | 0.70 – 0.90 |
| 6 | neutral    | 0.45 – 0.60 |
| 7 | productive | 0.05 – 0.25 |

Pass `?seed=42` to pin the RNG within each band for fully reproducible output.

---

## Upcoming phases

| Phase | Change |
|-------|--------|
| 4 | `webcam_analyzer.py` activated — `source` field becomes `"webcam"`, real scores from mediapipe FaceMesh |
| 5 | `/suggest` endpoint added — returns difficulty hints based on current state |
